#include <iostream>
#include <fstream>
using namespace std;
// without using string data type string library whole project on char data type
// global variable memory generate in heap memory of global variables
const int row = 15;
const int col = 15;
char board[row][col];
int level = 0;
void main_menu();                                // main menu
void word_searchFound(int, int &);               // show the word found result
void word_searchFound2(int &, int);              // show lives if word not found
int LengthRead_Word(const char *);               // calculate length of read_word from dictionary
bool password_check(const char[][5], char[][5]); // password checker
void read_board(ifstream &file);                 // read board from the file
void display_board();                            // show the board
void Level_Selection();                          // level selection menu
void NewGame();                                  // newgame if new user come and play
void pause_game(char[], int, int);               // write grid in file and store the current record
void input_word(char[], int &, int &, int);      // word search functions all processing
bool dictionary_board(char[], int);              // read data from dictionary file and return true or false
void Resume_Menu();                              // show the resume menu when user enetr p\P
void Resume_game();                              // resume menu if user resume the game while playing of entering P\P
void maxscore_lives();                           // after lives 0 or score reached to the maxscore
bool easy_level(char[], int);                    // easy level forward wise row & col
bool intermediate_level(char[], int);            // intermediate level reverse wise row & col
bool difficult_level(char[], int);               // difficult level check word in the daigonal form "X shape"
void Capital_convert(char[]);                    // covert smalls words into upper by manaully
void write_playerdata(char[], int);              // write data in the file name and score of the user
void update_highScore(char[], int);              // update and sort in ascending order and write data into file
void print_records();                            // print highest records on the console from files through reading the data
int main()
{
    const char id_user[2][5] = {{"game"}, {"1234"}};
    char input_user[2][5];
    int repeat = 1;
    while (repeat == 1)
    {
        cout << "\n\t|--------------------------------|" << endl;
        cout << "\t|  Welcome To Word Puzzle Game   |" << endl;
        cout << "\t|--------------------------------|" << endl;
        cout << " Enter Username ";
        cin >> input_user[0];
        cout << " Enter Password ";
        cin >> input_user[1];
        if (password_check(id_user, input_user))
        {
            repeat = 0;
            system("CLS");
            main_menu();
        }
        else
        {
            cout << "\n\n Username & Password, Invalid Try Again! " << endl;
        }
    }
    return 0;
}
void main_menu()
{
    char selection = '\0';
    do
    {
        cout << "\n\n\t|-------------------------------------------|" << endl;
        cout << "\t|                MAIN MENU                  |" << endl;
        cout << "\t|-------------------------------------------|" << endl;
        cout << "\t|       Enter 'N' for New Game              |" << endl;
        cout << "\t|       Enter 'R' for Resume Game           |" << endl;
        cout << "\t|       Enter 'H' for High Game             |" << endl;
        cout << "\t|       Enter 'E' for  Exit                 |" << endl;
        cout << "\t|-------------------------------------------|" << endl;
        cout << "\n Enter Your Selection ";
        cin >> selection;
        if (selection == 'n' || selection == 'N')
        {
            NewGame();
        }
        else if (selection == 'r' || selection == 'R')
        {
            Resume_game();
        }
        else if (selection == 'h' || selection == 'H')
        {
            print_records();
            system("PAUSE");
        }
        else if (selection == 'e' || selection == 'E')
        {

            cout << "\n Bye, See You Again!\n"
                 << endl;
            exit(0);
        }
        else
        {
            cout << "\n Invalid choice" << endl;
        }
    } while (true);
}
void read_board(ifstream &file)
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            file >> board[i][j];
        }
    }
}
void display_board()
{
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j < col; j++)
        {
            cout << board[i][j] << " ";
        }
        cout << "\n";
    }
}
void print_score(int lives, int score)
{
    cout << "\n";
    cout << " ---------------------------------" << endl;
    cout << "\tScore:  " << score << "  lives:  " << lives << endl;
    cout << " ---------------------------------" << endl;
}
void pause_game(char username[], int lives, int score)
{
    ofstream out;
    out.open("Pausedgame.txt");   // new file creating
    for (int i = 0; i < row; i++) //  writing grid in file
    {
        for (int j = 0; j < col; j++)
        {
            out << board[i][j];
        }
        out << "\n"; // new line after a row
    }
    out << username << " " << score << " " << lives << "\n"; // storing data of user
}
void input_word(char username[], int &lives, int &score, int maxscore)
{
    char word[20]; // for input the name
    int wordsize;  // for word size
    for (int i = 0; score < maxscore && lives > 0; i++)
    {
        cout << " \nEnter The Word: (Pause-> p/P) ";
        cin >> word;
        Capital_convert(word);                                     // capital words if user enter small words
        if ((word[0] == 'p' || word[0] == 'P') && word[1] == '\0') // chech if first index p/P or e/E, run the condition
        {
            pause_game(username, lives, score); // calling pause_game function
            Resume_Menu();                      // for exit or resume the menu
            break;                              // break the loop
        }
        wordsize = 0;
        int j = 0;
        while (word[j] != '\0') // calculate the word size
        {
            wordsize++;
            j++;
        }
        if (dictionary_board(word, wordsize))
        {
            if (level == 1)
            {
                if (easy_level(word, wordsize))
                {
                    word_searchFound(lives, score);
                }
                else
                {
                    word_searchFound2(lives, score);
                }
            }
            else if (level == 2) // intermediate level with easy level check from both them
            {
                if (easy_level(word, wordsize))
                {
                    word_searchFound(lives, score);
                }
                else if (intermediate_level(word, wordsize))
                {
                    word_searchFound(lives, score);
                }
                else
                {
                    word_searchFound2(lives, score);
                }
            }
            else if (level == 3) // difficult level with intermediate and easy level check from all of them
            {
                if (easy_level(word, wordsize))
                {
                    word_searchFound(lives, score);
                }
                else if (intermediate_level(word, wordsize))
                {
                    word_searchFound(lives, score);
                }
                else if (difficult_level(word, wordsize))
                {
                    word_searchFound(lives, score);
                }
                else
                {
                    word_searchFound2(lives, score);
                }
            }
        }
        else
        {
            cout << "Word Not Found In The Dictionary! " << endl;
            cout << "Try Again! " << endl;
        }
    }
}
void word_searchFound(int lives, int &score)
{
    cout << "Word Found! " << endl;
    score += 10;
    print_score(lives, score);
}
void word_searchFound2(int &lives, int score)
{
    cout << "Try Again, No Found!" << endl;
    lives--;
    print_score(lives, score);
}
bool difficult_level(char word[], int size)
{
    int check = 0;
    int index = size - 1;

    // For forward diagonal wise direction
    for (int r = 0; r <= row - size; r++)
    {
        for (int c = 0; c <= col - size; c++)
        {
            int check = 0;
            for (int a = 0; a < size; a++)
            {
                if (word[a] == board[r + a][c + a])
                    check++;
            }
            if (check == size)
                return true;
        }
    }

    // For backward diagonal wise direction
    for (int r = 0; r <= row - size; r++)
    {
        for (int c = col - 1; c >= size - 1; c--)
        {
            int check = 0;
            for (int a = 0; a < size; a++)
            {
                if (word[a] == board[r + a][c - a])
                    check++;
            }
            if (check == size)
                return true;
        }
    }

    // These are reverse of forward wise loops
    // For forward reverse diagonal wise direction
    for (int r = row - 1; r >= size - 1; r--)
    {
        for (int c = 0; c <= col - size; c++)
        {
            check = 0;
            index = size - 1;
            for (int a = 0; a < size; a++)
            {
                if (board[r - a][c + a] == word[index - a])
                    check++;
            }
            if (check == size)
            {
                return true;
            }
        }
    }

    // For backward reverse diagonal wise direction
    for (int r = row - 1; r >= size - 1; r--)
    {
        for (int c = col - 1; c >= size - 1; c--)
        {
            check = 0;
            index = size - 1;
            for (int a = 0; a < size; a++)
            {
                if (word[index - a] == board[r - a][c - a])
                    check++;
            }
            if (check == size)
            {
                return true;
            }
        }
    }
    return false;
}
bool intermediate_level(char word_input[], int size)
{
    // reverse row-wise searching in the grid
    int wordindex;
    int counter;
    for (int i = 0; i < row; i++)
    {
        wordindex = size - 1;
        counter = 0;
        // we don't run reverse loop, because we check in reverse order from the board
        for (int j = 0; j < col; j++) // search from right to left
        {
            if (board[i][j] == word_input[wordindex])
            {
                counter++;
                wordindex--;
            }
            else
            {
                counter = 0;
                wordindex = size - 1;
            }
            if (counter == size)
            {
                return true;
            }
        }
    }

    // reverse column-wise searching in the grid
    for (int j = 0; j < col; j++)
    {
        wordindex = size - 1;
        counter = 0;
        // same logic we compare word last index with board word first index
        for (int i = 0; i < row; i++) // search from bottom to top
        {
            if (board[i][j] == word_input[wordindex])
            {
                counter++;
                wordindex--;
            }
            else
            {
                counter = 0;
                wordindex = size - 1;
            }
            if (counter == size)
            {
                return true;
            }
        }
    }

    return false;
}
bool easy_level(char word_input[], int size)
{
    // forward row-wise searching in the grid
    for (int i = 0; i < row; i++)
    {
        for (int j = 0; j <= col - size; j++) // Ensure we don't start beyond the bounds
        {
            int k;
            for (k = 0; k < size; k++)
            {
                if (board[i][j + k] != word_input[k])
                {
                    break;
                }
            }
            if (k == size)
            {
                return true;
            }
        }
    }

    // forward column-wise searching in the grid
    for (int j = 0; j < col; j++)
    {
        for (int i = 0; i <= row - size; i++) // Ensure we don't start beyond the bounds
        {
            int k;
            for (k = 0; k < size; k++)
            {
                if (board[i + k][j] != word_input[k])
                {
                    break;
                }
            }
            if (k == size)
            {
                return true;
            }
        }
    }

    return false;
}
void Resume_game()
{
    ifstream in;
    in.open("Pausedgame.txt");
    if (!in)
    {
        cout << "\n No Paused Game Found!" << endl; // If file is not found
    }
    else
    {
        char player_name[20];
        int score, lives;
        int maxscore = 100; // Max Score is set to 100

        read_board(in); // Global 2-D array will be initialized with pause game board

        // Player name, Score, Lives will also readed after board
        in >> player_name;
        in >> score;
        in >> lives;

        in.close(); // Closing the file
        system("CLS");
        // Printing this message with readed player name
        cout << "\n\t\t  WELCOME BACK " << player_name << endl;
        // Calling this function to reselect the level by user
        Level_Selection();
        display_board(); // Printing paused board on console
        cout << "\n\tYour Previous Score:" << endl;
        print_score(lives, score); // Printing Previous Score and lives

        // Calling input_word function to continue the game from Paused game
        input_word(player_name, lives, score, maxscore);
        if (score == maxscore)
        {
            cout << "\n Congratulation, For Reaching At Highest Score!" << endl;
            update_highScore(player_name, score);
            maxscore_lives();
        }
        else if (lives == 0)
        {
            cout << "\n Try Again! Your lives is 0 " << endl;
            update_highScore(player_name, score);
            maxscore_lives();
        }
    }
}
void Resume_Menu()
{
    char choice[5];
    cout << " -------------------------------" << endl;
    cout << "\tPress 'E' For Exit " << endl;
    cout << "\tPress 'R' For Resume " << endl;
    cout << " -------------------------------" << endl;
n:
    cout << " Enter Your Choice ";
    cin >> choice;
    if (choice[0] == 'e' || choice[0] == 'E')
    {
        cout << "\n Bye, see yuu again\n"
             << endl;
        exit(0);
    }
    else if (choice[0] == 'r' || choice[0] == 'R')
    {
        system("CLS");
        main_menu();
    }
    else
    {
        cout << "\n Invalid Selection! Try Again" << endl;
        goto n;
    }
}
int LengthRead_Word(const char *str)
{
    int length = 0;
    while (str[length] != '\0')
    {
        length++;
    }
    return length;
}
bool dictionary_board(char word_input[], int wordsize)
{
    ifstream in("dictionary.txt");
    if (!in)
    {
        cout << "Dictionary Not Found!" << endl;
        return false;
    }
    char read_word[20];
    while (in >> read_word)
    {
        if (LengthRead_Word(read_word) == wordsize)
        {
            bool match = true;
            for (int k = 0; k < wordsize; k++)
            {
                if (read_word[k] != word_input[k])
                {
                    match = false;
                    break;
                }
            }
            if (match)
            {
                in.close();
                return true;
            }
        }
    }
    in.close();
    return false;
}
void NewGame()
{
    ifstream file;
    file.open("board.txt");
    if (!file)
    {
        cout << " Error While Opening File " << endl; // error if file don't exit
    }
    else
    {
        int lives = 3;
        int score = 0;
        int maxscore = 100;
        char name[20];
        system("CLS");
        cout << "\n\n Enter Your Name ";
        cin >> name; // get username

        read_board(file);  // read data from board file
        file.close();      // close file
        Level_Selection(); // selection menu
        cout << "\n";
        display_board(); // print the board after reading from the board file
        input_word(name, lives, score, maxscore);
        if (score == maxscore)
        {
            cout << "\n Congratulation, For Reaching At Highest Score!" << endl;
            update_highScore(name, score);
            maxscore_lives();
        }
        else if (lives == 0)
        {
            cout << "\n Try Again! Your lives is 0 " << endl;
            update_highScore(name, score);
            maxscore_lives();
        }
    }
}
void maxscore_lives()
{
    char choice = '\0';
    cout << "\n ------------------------" << endl;
    cout << " 1- Play Again? " << endl;
    cout << " 2- EXIT" << endl;
    cout << " ------------------------" << endl;
m: // label for something starting
    cout << " Your Choice? ";
    cin >> choice;
    if (choice == '1')
    {
        system("CLS");
        main_menu();
    }
    else if (choice == '2')
    {
        cout << "\n Bye, See You Again!\n"
             << endl;
        system("PAUSE");
        exit(0);
    }
    else
    {
        cout << "\n Invalid Choice! Try Again" << endl;
        goto m; // if invalid choice this label go to the m where it's define with (:)
    }
}
void Level_Selection()
{ // level selection system show on consloe after calling
    int choice = 0;
    cout << "\n\t|-------------------------------------|" << endl;
    cout << "\t|         Level Selection Menu        |" << endl;
    cout << "\t|-------------------------------------|" << endl;
    cout << "\t|    1- Easy-Level                    |" << endl;
    cout << "\t|    2- Intermediate-Level            |" << endl;
    cout << "\t|    3- Hard-Level                    |" << endl;
    cout << "\t|-------------------------------------|" << endl;
    cout << " Enter Your Choice ";
    cin >> choice;
    if (choice == 1)
    {
        system("CLS");
        cout << "\n\n\t| Easy-Level |" << endl;
        level = 1;
    }
    else if (choice == 2)
    {
        system("CLS");
        cout << "\n\n   | Intermediate-Level |" << endl;
        level = 2;
    }
    else if (choice == 3)
    {
        system("CLS");
        cout << "\n\n\t| Hard-Level |" << endl;
        level = 3;
    }
}
bool password_check(const char id_user[][5], char input_user[][5])
{
    for (int i = 0; i < 2; i++)
    {
        int j = 0;
        for (; input_user[i][j] != '\0'; j++)
        {
            if (input_user[i][j] != id_user[i][j])
            {
                return false;
            }
        }
        if (input_user[i][j] != '\0' || id_user[i][j] != '\0')
        // chech if one string is longer or shorter, then other one
        {
            return false;
        }
    }
    return true;
}
void Capital_convert(char word[])
{
    for (int i = 0; word[i] != '\0'; i++)
    {
        if (word[i] >= 'a' && word[i] <= 'z')
        {
            word[i] = word[i] - 32; // Convert to uppercase
        }
    }
}
void update_highScore(char name[], int score)
{
    ifstream in;
    in.open("highrecord.txt");
    if (!in) // if file is not open
    {
        // make new file with same name because when file was not found
        // then created write username and score of user
        ofstream out("highrecord.txt");
        out << name << " " << score; // write data of the user
        out.close();                 // closing file
    }
    else
    {
        // Using Dynamic 2-D Array for reading name from file
        char **read_name = new char *[5]; // dynamic 2-D array syntax and create 5 arrays
        for (int a = 0; a < 5; a++)
        {
            read_name[a] = new char[15];
        }
        int read_score[5]; // 1_D static array for score
        int k = 0;
        while (k < 5 && !in.eof()) // read data from file
        {
            in >> read_name[k];  // read name
            in >> read_score[k]; // read score
            k++;                 // update k value
        }
        // If there are 5 records in file, than the last one will be changed
        // loop value is 5 because when upper for loop
        // break the condition when loop value after update is 5
        if (k == 5)
        {
            if (score > read_score[4]) // check the score if the score is greater then of file read_score
            {
                read_score[4] = score;
                int a = 0;
                while (name[a] != '\0') // loop run untill the \0 is coming at the end of name
                {

                    read_name[4][a] = name[a]; // replace last user data column wise
                    a++;
                }
                read_name[4][a] = '\0'; // place null character at end of name when for loop break
            }
        }
        // If there are less than 5 records int the file than the next index will be initialized
        else
        {
            read_score[k] = score; // score replace
            int b = 0;
            for (b = 0; name[b] != '\0'; b++) // loop run untill the \0 is coming at the end of name
            {
                read_name[k][b] = name[b];
            }
            read_name[k][b] = '\0'; // place null character at end of name when for loop break
            k++;                    // increment in loop variable
        }
        // Loop to arrange the score in Ascending Order
        for (int x = 0; x < k; x++)
        {
            for (int y = 0; y < k - 1; y++)
            {
                if (read_score[x] > read_score[y])
                {
                    int temp = read_score[x];      // temp got read_score value
                    read_score[x] = read_score[y]; // read_score [x] got read_score [y]
                    read_score[y] = temp;          // read_score [y] got temp value
                    char *tem = NULL;              // for replace the name also without name was not swap but score swap with another name
                    tem = read_name[x];
                    read_name[x] = read_name[y];
                    read_name[y] = tem;
                }
            }
        }
        // Creatin new file to save the records in ascending order
        ofstream out2("highrecord.txt"); // creating again file with same name
        for (int a = 0; a < k; a++)      // loop value of upper where ever it upgraded
        {
            if (a == 0) // for no going to the next line auto
            {
                out2 << read_name[a] << " " << read_score[a];
            }
            else // for write data on next line because we don't want extre line move at end
            {
                out2 << "\n"
                     << read_name[a] << " " << read_score[a];
            }
        }
        out2.close(); // closing file
        in.close();   // closing file

        // Deleting the dynamic 2-D Array, cuz it's compulsory
        for (int a = 0; a < 5; a++)
        {
            delete[] read_name[a];
        }
        delete[] read_name;
    }
}
void print_records()
{
    ifstream in("highrecord.txt");
    if (!in.is_open())
    {
        cout << "\nHigh Records File Not Found!..." << endl; // If high record file not found
    }
    else
    {
        // Using 2-D Array for names
        char **read_name = new char *[5];
        for (int a = 0; a < 5; a++)
        {
            read_name[a] = new char[20];
        }

        int read_score[5];
        // Loop to initialize the name and score array with data in highrecord file
        int a;
        for (a = 0; a < 5 && !in.eof(); a++)
        {
            in >> read_name[a];
            in >> read_score[a];
        }
        in.close(); // Closing the file

        cout << "\n\t---------------------------------------" << endl;
        cout << "\t\t--Highest Five Records--" << endl;
        cout << "\tNo. Names\t\tScores" << endl;

        // Printing the names and scores on console
        for (int b = 0; b < a; b++)
        {
            cout << "\t" << b + 1 << ".  " << read_name[b] << "  \t\t" << read_score[b] << endl;
        }
        cout << "\t---------------------------------------" << endl;

        // Deallocating the 2-d dynamic array
        for (int a = 0; a < 5; a++)
        {
            delete[] read_name[a];
        }
        delete[] read_name;
    }
}